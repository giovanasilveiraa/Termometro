﻿namespace prjTermometro1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pnFrom = new System.Windows.Forms.Panel();
            this.label = new System.Windows.Forms.Label();
            this.rbFromC = new System.Windows.Forms.RadioButton();
            this.rbFromF = new System.Windows.Forms.RadioButton();
            this.rbFromK = new System.Windows.Forms.RadioButton();
            this.pnTo = new System.Windows.Forms.Panel();
            this.rbToK = new System.Windows.Forms.RadioButton();
            this.rbToF = new System.Windows.Forms.RadioButton();
            this.rbToC = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTemperatura = new System.Windows.Forms.TextBox();
            this.btnConverter = new System.Windows.Forms.Button();
            this.lblTemperatura = new System.Windows.Forms.Label();
            this.pnFrom.SuspendLayout();
            this.pnTo.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnFrom
            // 
            this.pnFrom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnFrom.Controls.Add(this.rbFromK);
            this.pnFrom.Controls.Add(this.rbFromF);
            this.pnFrom.Controls.Add(this.rbFromC);
            this.pnFrom.Controls.Add(this.label);
            this.pnFrom.Location = new System.Drawing.Point(18, 15);
            this.pnFrom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pnFrom.Name = "pnFrom";
            this.pnFrom.Size = new System.Drawing.Size(156, 189);
            this.pnFrom.TabIndex = 0;
            // 
            // label
            // 
            this.label.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label.Dock = System.Windows.Forms.DockStyle.Top;
            this.label.Location = new System.Drawing.Point(0, 0);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(154, 19);
            this.label.TabIndex = 0;
            this.label.Text = "ORIGEM";
            this.label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rbFromC
            // 
            this.rbFromC.AutoSize = true;
            this.rbFromC.Checked = true;
            this.rbFromC.Location = new System.Drawing.Point(3, 47);
            this.rbFromC.Name = "rbFromC";
            this.rbFromC.Size = new System.Drawing.Size(87, 20);
            this.rbFromC.TabIndex = 1;
            this.rbFromC.TabStop = true;
            this.rbFromC.Text = "CELSIUS";
            this.rbFromC.UseVisualStyleBackColor = true;
            // 
            // rbFromF
            // 
            this.rbFromF.AutoSize = true;
            this.rbFromF.Location = new System.Drawing.Point(3, 95);
            this.rbFromF.Name = "rbFromF";
            this.rbFromF.Size = new System.Drawing.Size(118, 20);
            this.rbFromF.TabIndex = 2;
            this.rbFromF.Text = "FAHRENHEIT";
            this.rbFromF.UseVisualStyleBackColor = true;
            // 
            // rbFromK
            // 
            this.rbFromK.AutoSize = true;
            this.rbFromK.Location = new System.Drawing.Point(3, 144);
            this.rbFromK.Name = "rbFromK";
            this.rbFromK.Size = new System.Drawing.Size(78, 20);
            this.rbFromK.TabIndex = 3;
            this.rbFromK.Text = "KELVIN";
            this.rbFromK.UseVisualStyleBackColor = true;
            // 
            // pnTo
            // 
            this.pnTo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnTo.Controls.Add(this.rbToK);
            this.pnTo.Controls.Add(this.rbToF);
            this.pnTo.Controls.Add(this.rbToC);
            this.pnTo.Controls.Add(this.label1);
            this.pnTo.Location = new System.Drawing.Point(18, 226);
            this.pnTo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pnTo.Name = "pnTo";
            this.pnTo.Size = new System.Drawing.Size(156, 189);
            this.pnTo.TabIndex = 1;
            // 
            // rbToK
            // 
            this.rbToK.AutoSize = true;
            this.rbToK.Checked = true;
            this.rbToK.Location = new System.Drawing.Point(3, 145);
            this.rbToK.Name = "rbToK";
            this.rbToK.Size = new System.Drawing.Size(78, 20);
            this.rbToK.TabIndex = 3;
            this.rbToK.TabStop = true;
            this.rbToK.Text = "KELVIN";
            this.rbToK.UseVisualStyleBackColor = true;
            // 
            // rbToF
            // 
            this.rbToF.AutoSize = true;
            this.rbToF.Location = new System.Drawing.Point(3, 96);
            this.rbToF.Name = "rbToF";
            this.rbToF.Size = new System.Drawing.Size(118, 20);
            this.rbToF.TabIndex = 2;
            this.rbToF.Text = "FAHRENHEIT";
            this.rbToF.UseVisualStyleBackColor = true;
            // 
            // rbToC
            // 
            this.rbToC.AutoSize = true;
            this.rbToC.Location = new System.Drawing.Point(3, 47);
            this.rbToC.Name = "rbToC";
            this.rbToC.Size = new System.Drawing.Size(87, 20);
            this.rbToC.TabIndex = 1;
            this.rbToC.Text = "CELSIUS";
            this.rbToC.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "DESTINO";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lblTemperatura);
            this.panel1.Controls.Add(this.btnConverter);
            this.panel1.Controls.Add(this.txtTemperatura);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(195, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(223, 400);
            this.panel1.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(221, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "TEMPERATURA";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(178, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "DIGITE A TEMPERATURA";
            // 
            // txtTemperatura
            // 
            this.txtTemperatura.Location = new System.Drawing.Point(15, 78);
            this.txtTemperatura.MaxLength = 10;
            this.txtTemperatura.Name = "txtTemperatura";
            this.txtTemperatura.Size = new System.Drawing.Size(175, 23);
            this.txtTemperatura.TabIndex = 3;
            this.txtTemperatura.Text = "0";
            this.txtTemperatura.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTemperatura_KeyPress);
            // 
            // btnConverter
            // 
            this.btnConverter.BackColor = System.Drawing.Color.White;
            this.btnConverter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConverter.Image = ((System.Drawing.Image)(resources.GetObject("btnConverter.Image")));
            this.btnConverter.Location = new System.Drawing.Point(15, 121);
            this.btnConverter.Name = "btnConverter";
            this.btnConverter.Size = new System.Drawing.Size(179, 138);
            this.btnConverter.TabIndex = 4;
            this.btnConverter.Text = "CONVERTER ";
            this.btnConverter.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnConverter.UseVisualStyleBackColor = false;
            this.btnConverter.Click += new System.EventHandler(this.btnConverter_Click);
            // 
            // lblTemperatura
            // 
            this.lblTemperatura.BackColor = System.Drawing.Color.White;
            this.lblTemperatura.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTemperatura.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTemperatura.Location = new System.Drawing.Point(15, 280);
            this.lblTemperatura.Name = "lblTemperatura";
            this.lblTemperatura.Size = new System.Drawing.Size(179, 99);
            this.lblTemperatura.TabIndex = 5;
            this.lblTemperatura.Text = "0,00";
            this.lblTemperatura.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(468, 428);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnTo);
            this.Controls.Add(this.pnFrom);
            this.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TERMOMETRO - CONVERSOR";
            this.pnFrom.ResumeLayout(false);
            this.pnFrom.PerformLayout();
            this.pnTo.ResumeLayout(false);
            this.pnTo.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnFrom;
        private System.Windows.Forms.RadioButton rbFromK;
        private System.Windows.Forms.RadioButton rbFromF;
        private System.Windows.Forms.RadioButton rbFromC;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Panel pnTo;
        private System.Windows.Forms.RadioButton rbToK;
        private System.Windows.Forms.RadioButton rbToF;
        private System.Windows.Forms.RadioButton rbToC;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblTemperatura;
        private System.Windows.Forms.Button btnConverter;
        private System.Windows.Forms.TextBox txtTemperatura;
    }
}

